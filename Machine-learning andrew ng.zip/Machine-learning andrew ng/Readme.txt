If You Have Taken Andrew Ng's Machine Learning Course On Coursera..

And You Are Learning From There Just For Concepts Not For Implementation

Of Algorithms As They Are Using Octave Instead Of Python or R.... But

Anyhow You Need To Complete Assignments Then


These Assignments Are For U�.


In case you are stucked do let me know in the comment section ...

happy learning :- )
